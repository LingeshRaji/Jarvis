# JARVIS - local AI assistant

Fully offline voice assistant for Linux: wake word, speech-to-text, a local LLM that can call tools, and spoken replies. Nothing leaves your machine.

```
mic -> openWakeWord ("Hey Jarvis") -> faster-whisper (CPU) -> Ollama LLM (GPU) -> tools -> Piper TTS -> speaker
                                                                   |
                                              SQLite memory + notes search (nomic-embed-text)
```

## Setup (sized for 24 GB RAM + 6 GB NVIDIA GPU)

```bash
chmod +x setup.sh && ./setup.sh
source .venv/bin/activate
python jarvis.py --text      # test with keyboard first
python jarvis.py --push      # press Enter, then speak
python jarvis.py             # full hands-free: say "Hey Jarvis"
```

## What it can do

| Tool | Example |
|---|---|
| system_status | "How's my system doing?" |
| open_app / open_url | "Open Firefox", "Open github.com" |
| set_volume | "Set volume to 40" |
| run_shell | "What's my IP address?" (risky commands ask for confirmation) |
| take_note / search_notes | "Note that the CEH exam is on the 15th", "What did I note about Burp?" |
| remember_fact | "Remember that I prefer dark themes" |
| read_file | "Summarise ~/scans/lab.nmap" |
| nmap_scan | "Quick scan 192.168.56.101" (only targets in `AUTHORISED_TARGETS`) |

Drop `.md` / `.txt` files into `~/jarvis_notes/` and Jarvis can search them.

## Files

- `config.py` - model, voice, persona, safety lists. Start here.
- `jarvis.py` - main loop and LLM tool-calling.
- `tools.py` - add new abilities: write a function, add it to `TOOLS`.
- `voice.py` - wake word, STT, TTS.
- `memory.py` - long-term facts and note search.

## Tuning

- Slow replies: set `LLM_MODEL = "qwen2.5:3b-instruct"` (fits fully in 6 GB VRAM).
- Better reasoning, slower: try `qwen3:8b` or `llama3.1:8b`.
- Mic cuts you off or never stops: adjust `SILENCE_RMS` / `SILENCE_SECONDS`.
- Wake word misfires: raise the 0.5 threshold in `voice.wait_for_wake_word`.

## Safety notes

- Shell commands outside the `SAFE_COMMANDS` list, or any chained/piped command, require spoken or typed confirmation. `BLOCKED_PATTERNS` are never run.
- `nmap_scan` refuses anything outside `AUTHORISED_TARGETS`. Only add systems you own or have written permission to test.
- Small local models can misread a command. Read what it is about to run before saying yes.

## Ideas for next steps

GUI/HUD overlay, Home Assistant control, screen reading with a vision model (`qwen2.5vl`), report-writing helper for your pentest lab project, richer cyber tools (nikto, gobuster output summaries).
