"""Voice I/O: wake word -> record -> faster-whisper STT; Piper TTS. All offline."""
import subprocess
import tempfile
import time

import numpy as np
import sounddevice as sd
import soundfile as sf

import config

_whisper = None
_oww = None


def _get_whisper():
    global _whisper
    if _whisper is None:
        from faster_whisper import WhisperModel
        _whisper = WhisperModel(config.WHISPER_MODEL, device=config.WHISPER_DEVICE,
                                compute_type=config.WHISPER_COMPUTE)
    return _whisper


def wait_for_wake_word() -> None:
    """Block until the wake word is heard."""
    global _oww
    from openwakeword.model import Model
    if _oww is None:
        import openwakeword
        openwakeword.utils.download_models([config.WAKE_WORD])
        _oww = Model(wakeword_models=[config.WAKE_WORD], inference_framework="onnx")
    _oww.reset()
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="int16", blocksize=1280) as stream:
        while True:
            frame, _ = stream.read(1280)
            scores = _oww.predict(frame[:, 0])
            if max(scores.values()) > 0.5:
                return


def record_until_silence() -> np.ndarray:
    """Record the user's command; stop after a pause."""
    chunks, silent_for, started = [], 0.0, False
    t0 = time.time()
    block = int(config.SAMPLE_RATE * 0.1)
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="float32", blocksize=block) as stream:
        while time.time() - t0 < config.MAX_RECORD_SECONDS:
            data, _ = stream.read(block)
            rms = float(np.sqrt(np.mean(data ** 2)))
            chunks.append(data[:, 0])
            if rms > config.SILENCE_RMS:
                started, silent_for = True, 0.0
            elif started:
                silent_for += 0.1
                if silent_for >= config.SILENCE_SECONDS:
                    break
            elif time.time() - t0 > 6:  # nobody spoke after wake word
                break
    return np.concatenate(chunks) if chunks else np.zeros(1, dtype="float32")


def transcribe(audio: np.ndarray) -> str:
    segments, _ = _get_whisper().transcribe(audio, language="en", vad_filter=True, beam_size=1)
    return " ".join(s.text.strip() for s in segments).strip()


def listen() -> str:
    return transcribe(record_until_silence())


def speak(text: str) -> None:
    """Speak via Piper; falls back to printing if the voice isn't installed."""
    print(f"JARVIS: {text}")
    if not config.PIPER_VOICE.exists():
        return
    with tempfile.NamedTemporaryFile(suffix=".wav") as f:
        subprocess.run(["piper", "--model", str(config.PIPER_VOICE), "--output_file", f.name],
                       input=text.encode(), capture_output=True)
        data, sr = sf.read(f.name)
        sd.play(data, sr)
        sd.wait()
