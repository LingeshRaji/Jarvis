#!/usr/bin/env bash
# One-shot setup for Jarvis on Linux. Run: ./setup.sh
set -e
cd "$(dirname "$0")"

echo "==> System packages (needs sudo): audio libs + nmap"
if command -v pacman >/dev/null; then
  sudo pacman -S --needed --noconfirm python python-pip portaudio libsndfile nmap pipewire-pulse
elif command -v apt >/dev/null; then
  sudo apt update && sudo apt install -y python3 python3-venv python3-pip portaudio19-dev libsndfile1 nmap
fi

echo "==> Ollama"
command -v ollama >/dev/null || curl -fsSL https://ollama.com/install.sh | sh
(pgrep -x ollama >/dev/null || (nohup ollama serve >/dev/null 2>&1 &) ) ; sleep 3

echo "==> Models (about 5 GB total)"
ollama pull qwen2.5:7b-instruct
ollama pull nomic-embed-text

echo "==> Python env"
python3 -m venv .venv
. .venv/bin/activate
pip install -U pip
pip install -r requirements.txt

echo "==> Piper voice"
mkdir -p ~/.jarvis/voices && cd ~/.jarvis/voices
base=https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/alan/medium
[ -f en_GB-alan-medium.onnx ]      || curl -L -O $base/en_GB-alan-medium.onnx
[ -f en_GB-alan-medium.onnx.json ] || curl -L -O $base/en_GB-alan-medium.onnx.json

echo
echo "Done. Start with:  source .venv/bin/activate && python jarvis.py --text"
