"""Central configuration for Jarvis. Edit this file to tune behaviour."""
from pathlib import Path

HOME = Path.home() / ".jarvis"
HOME.mkdir(exist_ok=True)

# --- LLM (served locally by Ollama) -----------------------------------------
# Sized for 6GB VRAM: a 4-bit 7-8B model fits (mostly) on GPU, rest spills to RAM.
LLM_MODEL = "qwen2.5:7b-instruct"      # good tool-calling. Alternatives: llama3.1:8b, qwen3:8b
LLM_FALLBACK = "qwen2.5:3b-instruct"   # faster if the 7B feels slow
OLLAMA_HOST = "http://127.0.0.1:11434"
LLM_OPTIONS = {"temperature": 0.4, "num_ctx": 4096}

# --- Persona -----------------------------------------------------------------
USER_NAME = "Lingesh"
WAKE_WORD = "hey_jarvis"               # built-in openWakeWord model
SYSTEM_PROMPT = f"""You are JARVIS, a concise, witty, highly capable local AI assistant
running entirely on {USER_NAME}'s Linux machine. Address the user as "sir" occasionally.
Keep spoken answers short (1-3 sentences) unless asked for detail.
You can call tools to control the computer, search notes, and remember facts.
Only call a tool when it is actually needed. Never invent tool results.
For security work: you assist with authorised testing, CTFs and the user's own lab only."""

# --- Speech ------------------------------------------------------------------
WHISPER_MODEL = "small.en"             # runs on CPU (int8) so the GPU stays free for the LLM
WHISPER_DEVICE = "cpu"
WHISPER_COMPUTE = "int8"
SAMPLE_RATE = 16000
SILENCE_SECONDS = 1.2                  # stop recording after this much silence
SILENCE_RMS = 0.012                    # mic energy threshold for "silence"
MAX_RECORD_SECONDS = 20

PIPER_VOICE = HOME / "voices" / "en_GB-alan-medium.onnx"   # downloaded by setup.sh

# --- Safety ------------------------------------------------------------------
# Shell commands matching these run without asking. Everything else asks for confirmation.
SAFE_COMMANDS = {"ls", "pwd", "whoami", "date", "uptime", "df", "free", "uname",
                 "ip", "ifconfig", "ping", "cat", "head", "tail", "echo", "which"}
# Security helper: scans are only allowed against these targets (your own lab / authorised scope).
AUTHORISED_TARGETS = ["127.0.0.1", "localhost", "192.168.56.0/24"]
# Never run, even if confirmed.
BLOCKED_PATTERNS = ["rm -rf /", "mkfs", ":(){", "dd if=", "> /dev/sd", "chmod -R 777 /"]

# --- Paths -------------------------------------------------------------------
MEMORY_DB = HOME / "memory.db"
NOTES_DIR = Path.home() / "jarvis_notes"   # drop .txt/.md files here for document Q&A
NOTES_DIR.mkdir(exist_ok=True)
