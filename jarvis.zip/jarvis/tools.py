"""Tools Jarvis can call. Each tool is a plain function plus a JSON schema for the LLM."""
import ipaddress
import os
import shlex
import shutil
import subprocess
from datetime import datetime

import psutil

import config
import memory

# Set by jarvis.py so risky actions can ask the user (by voice or keyboard).
confirm = lambda prompt: input(f"{prompt} [y/N] ").strip().lower() == "y"


# --- implementations ---------------------------------------------------------
def get_time() -> str:
    return datetime.now().strftime("%A, %d %B %Y, %I:%M %p")


def system_status() -> str:
    vm = psutil.virtual_memory()
    bat = psutil.sensors_battery()
    out = f"CPU {psutil.cpu_percent(interval=0.5)}%, RAM {vm.percent}% of {vm.total // 2**30}GB, disk {psutil.disk_usage('/').percent}% used"
    if bat:
        out += f", battery {bat.percent:.0f}%{' (charging)' if bat.power_plugged else ''}"
    if shutil.which("nvidia-smi"):
        g = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                            "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
        out += f", GPU {g}"
    return out


def open_app(name: str) -> str:
    exe = shutil.which(name.lower().replace(" ", "-")) or shutil.which(name.lower())
    if not exe:
        return f"I can't find an app called {name}."
    subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"Opened {name}."


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"Opening {url}."


def set_volume(percent: int) -> str:
    percent = max(0, min(100, int(percent)))
    if shutil.which("wpctl"):
        cmd = ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{percent}%"]
    elif shutil.which("amixer"):
        cmd = ["amixer", "sset", "Master", f"{percent}%"]
    else:
        return "No volume control found (install pipewire or alsa-utils)."
    subprocess.run(cmd, capture_output=True)
    return f"Volume set to {percent}%."


def run_shell(command: str) -> str:
    low = command.lower()
    if any(p in low for p in config.BLOCKED_PATTERNS):
        return "Blocked: that command is on the never-run list."
    try:
        first = shlex.split(command)[0]
    except (ValueError, IndexError):
        return "Could not parse that command."
    chained = any(c in command for c in [";", "&&", "||", "|", ">", "`", "$("])
    if first not in config.SAFE_COMMANDS or chained:
        if not confirm(f"Run shell command: {command}?"):
            return "Cancelled by user."
    try:
        r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=60)
        return ((r.stdout or "") + (r.stderr or "")).strip()[-3000:] or "(no output)"
    except subprocess.TimeoutExpired:
        return "Command timed out after 60s."


def read_file(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        return "File not found."
    with open(p, errors="ignore") as f:
        return f.read(6000)


def take_note(text: str) -> str:
    f = config.NOTES_DIR / f"{datetime.now():%Y-%m-%d}.md"
    with open(f, "a") as fh:
        fh.write(f"- {datetime.now():%H:%M} {text}\n")
    return "Note saved."


def remember_fact(fact: str) -> str:
    return memory.remember(fact)


def search_notes(query: str) -> str:
    memory.index_notes()
    return memory.search_notes(query)


def _in_scope(target: str) -> bool:
    try:
        ip = ipaddress.ip_address(target)
    except ValueError:
        return target in config.AUTHORISED_TARGETS
    for t in config.AUTHORISED_TARGETS:
        try:
            if ip in ipaddress.ip_network(t, strict=False):
                return True
        except ValueError:
            continue
    return False


def nmap_scan(target: str, mode: str = "quick") -> str:
    """Scan only targets listed in config.AUTHORISED_TARGETS."""
    if not _in_scope(target):
        return f"{target} is not in your authorised scope. Add it to AUTHORISED_TARGETS in config.py if you own it or have written permission."
    if not shutil.which("nmap"):
        return "nmap is not installed."
    args = {"quick": ["-T4", "-F"], "service": ["-sV", "-T4", "--top-ports", "200"]}.get(mode, ["-T4", "-F"])
    r = subprocess.run(["nmap", *args, target], capture_output=True, text=True, timeout=600)
    return r.stdout[-3500:] or r.stderr


# --- registry ----------------------------------------------------------------
def _fn(name, desc, props=None, required=None):
    return {"type": "function", "function": {
        "name": name, "description": desc,
        "parameters": {"type": "object", "properties": props or {}, "required": required or []}}}


_S = lambda d: {"type": "string", "description": d}

TOOLS = {
    "get_time": (get_time, _fn("get_time", "Get the current date and time.")),
    "system_status": (system_status, _fn("system_status", "Report CPU, RAM, disk, battery and GPU status.")),
    "open_app": (open_app, _fn("open_app", "Launch a desktop application by name.", {"name": _S("app name, e.g. firefox")}, ["name"])),
    "open_url": (open_url, _fn("open_url", "Open a website in the default browser.", {"url": _S("URL")}, ["url"])),
    "set_volume": (set_volume, _fn("set_volume", "Set system volume 0-100.", {"percent": {"type": "integer"}}, ["percent"])),
    "run_shell": (run_shell, _fn("run_shell", "Run a shell command on the Linux machine. Risky commands ask the user first.", {"command": _S("the command")}, ["command"])),
    "read_file": (read_file, _fn("read_file", "Read the start of a text file (e.g. a scan output) so it can be summarised.", {"path": _S("file path")}, ["path"])),
    "take_note": (take_note, _fn("take_note", "Append a note to today's notes file.", {"text": _S("note text")}, ["text"])),
    "remember_fact": (remember_fact, _fn("remember_fact", "Store a durable fact about the user or their preferences in long-term memory.", {"fact": _S("the fact")}, ["fact"])),
    "search_notes": (search_notes, _fn("search_notes", "Semantic search over the user's notes folder.", {"query": _S("what to look for")}, ["query"])),
    "nmap_scan": (nmap_scan, _fn("nmap_scan", "Run an nmap scan against an authorised lab target.", {"target": _S("IP or hostname in scope"), "mode": {"type": "string", "enum": ["quick", "service"]}}, ["target"])),
}

SCHEMAS = [v[1] for v in TOOLS.values()]


def call(name: str, args: dict) -> str:
    if name not in TOOLS:
        return f"Unknown tool {name}."
    try:
        return str(TOOLS[name][0](**args))
    except Exception as e:  # keep the assistant alive on tool errors
        return f"Tool {name} failed: {e}"
