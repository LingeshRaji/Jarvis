#!/usr/bin/env python3
"""JARVIS - fully local voice assistant.

  python jarvis.py            # voice mode: say "Hey Jarvis", then your request
  python jarvis.py --text     # keyboard mode (good for testing)
  python jarvis.py --push     # voice without wake word: press Enter, then speak
"""
import argparse
import json

import ollama

import config
import memory
import tools

client = ollama.Client(host=config.OLLAMA_HOST)
MAX_TOOL_ROUNDS = 4
MAX_HISTORY = 16


def build_system() -> str:
    return config.SYSTEM_PROMPT


def think(history: list, user_text: str) -> str:
    """One user turn: recall memory, let the model call tools, return the final reply."""
    try:
        facts = memory.recall(user_text)
    except Exception:
        facts = []  # embedding model not pulled yet - carry on without memory
    sys_msg = build_system()
    if facts:
        sys_msg += "\n\nKnown facts about the user:\n- " + "\n- ".join(facts)

    history.append({"role": "user", "content": user_text})
    messages = [{"role": "system", "content": sys_msg}] + history[-MAX_HISTORY:]

    for _ in range(MAX_TOOL_ROUNDS):
        resp = client.chat(model=config.LLM_MODEL, messages=messages,
                           tools=tools.SCHEMAS, options=config.LLM_OPTIONS)
        msg = resp["message"]
        messages.append(msg)
        calls = msg.get("tool_calls") or []
        if not calls:
            reply = (msg.get("content") or "").strip() or "Done."
            history.append({"role": "assistant", "content": reply})
            return reply
        for c in calls:
            name, args = c["function"]["name"], c["function"]["arguments"]
            if isinstance(args, str):
                args = json.loads(args or "{}")
            print(f"  [tool] {name}({args})")
            messages.append({"role": "tool", "name": name, "content": tools.call(name, args)})

    reply = "I got stuck in a loop on that one, sir."
    history.append({"role": "assistant", "content": reply})
    return reply


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--push", action="store_true")
    args = ap.parse_args()

    voice = None
    if not args.text:
        import voice  # heavy imports only when needed
        tools.confirm = lambda prompt: (voice.speak(prompt + " Say yes to confirm."), "yes" in voice.listen().lower())[1]

    # warm the model so the first reply isn't slow
    try:
        client.chat(model=config.LLM_MODEL, messages=[{"role": "user", "content": "hi"}], options={"num_predict": 1})
    except Exception as e:
        raise SystemExit(f"Can't reach Ollama / model '{config.LLM_MODEL}': {e}\nRun ./setup.sh first.")

    say = voice.speak if voice else (lambda t: print(f"JARVIS: {t}"))
    say(f"Systems online. How can I help, {config.USER_NAME}?")
    history: list = []

    while True:
        try:
            if args.text:
                text = input("you> ").strip()
            elif args.push:
                input("[press Enter and speak] ")
                text = voice.listen()
                print(f"you> {text}")
            else:
                voice.wait_for_wake_word()
                print("(listening)")
                text = voice.listen()
                print(f"you> {text}")
        except (KeyboardInterrupt, EOFError):
            say("Shutting down.")
            break

        if not text:
            continue
        if text.lower().strip(" .!") in {"exit", "quit", "goodbye", "shut down"}:
            say("Goodbye, sir.")
            break
        say(think(history, text))


if __name__ == "__main__":
    main()
